from gemini_client import generate_json

QUIZ_SCHEMA = {
    "type": "object",
    "properties": {
        "questions": {
            "type": "array",
            "minItems": 3,
            "maxItems": 3,
            "items": {
                "type": "object",
                "properties": {
                    "question": {"type": "string"},
                    "options": {
                        "type": "array",
                        "minItems": 4,
                        "maxItems": 4,
                        "items": {"type": "string"},
                    },
                    "correct_answer": {"type": "string"},
                    "explanation": {"type": "string"},
                },
                "required": ["question", "options", "correct_answer", "explanation"],
            },
        }
    },
    "required": ["questions"],
}

SYSTEM = """
Create educational multiple-choice quizzes.
Generate exactly 3 questions, each with exactly 4 options.
The correct_answer must exactly match one option.
Include a short explanation for the correct answer.
Questions must be answerable from the supplied topic or passage.
"""

def generate_quiz(text: str) -> dict:
    return generate_json(
        f"Create a quiz from this topic/passage:\n{text}",
        QUIZ_SCHEMA,
        system_instruction=SYSTEM,
        temperature=0.4,
        max_output_tokens=1600,
    )
