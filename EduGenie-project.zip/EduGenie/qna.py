from gemini_client import generate_text

SYSTEM = """
You are EduGenie, a patient educational assistant.
Answer the learner's question accurately and concisely.
Use simple language, short paragraphs, and bullet points when useful.
If a question is ambiguous, state the ambiguity and answer the most reasonable interpretation.
Do not invent citations or claim certainty when the information is uncertain.
"""

def answer_question(question: str) -> str:
    return generate_text(
        f"Learner question:\n{question}\n\nGive a clear educational answer.",
        system_instruction=SYSTEM,
        temperature=0.2,
        max_output_tokens=1000,
    )
