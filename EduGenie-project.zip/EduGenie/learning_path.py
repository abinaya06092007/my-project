from gemini_client import generate_text

SYSTEM = """
You are an educational learning-path planner.
Create a practical progression from beginner to advanced.
Include suggested time ranges, prerequisite concepts, practice activities,
and resource types such as documentation, books, articles, or videos.
Do not fabricate specific URLs. Keep recommendations topic-focused.
"""

def get_learning_recommendations(topic: str) -> str:
    return generate_text(
        f"Build a beginner-to-advanced learning path for:\n{topic}",
        system_instruction=SYSTEM,
        temperature=0.4,
        max_output_tokens=1400,
    )
