import os
from functools import lru_cache
from google import genai
from google.genai import types

MODEL = os.getenv("GEMINI_MODEL", "gemini-2.5-flash")


@lru_cache(maxsize=1)
def get_client() -> genai.Client:
    api_key = os.getenv("GEMINI_API_KEY")
    if not api_key:
        raise RuntimeError(
            "GEMINI_API_KEY is not configured. Copy .env.example to .env and add your Gemini API key."
        )
    return genai.Client(api_key=api_key)


def generate_text(prompt: str, *, system_instruction: str | None = None,
                  temperature: float = 0.3, max_output_tokens: int = 1200) -> str:
    config = types.GenerateContentConfig(
        temperature=temperature,
        max_output_tokens=max_output_tokens,
        system_instruction=system_instruction,
    )
    response = get_client().models.generate_content(
        model=MODEL,
        contents=prompt,
        config=config,
    )
    text = getattr(response, "text", None)
    if not text:
        raise RuntimeError("Gemini returned an empty response.")
    return text.strip()


def generate_json(prompt: str, schema: dict, *,
                  system_instruction: str | None = None,
                  temperature: float = 0.2,
                  max_output_tokens: int = 1600) -> dict:
    config = types.GenerateContentConfig(
        temperature=temperature,
        max_output_tokens=max_output_tokens,
        system_instruction=system_instruction,
        response_mime_type="application/json",
        response_schema=schema,
    )
    response = get_client().models.generate_content(
        model=MODEL,
        contents=prompt,
        config=config,
    )
    if not getattr(response, "text", None):
        raise RuntimeError("Gemini returned an empty JSON response.")
    import json
    try:
        return json.loads(response.text)
    except json.JSONDecodeError as exc:
        raise RuntimeError(f"Gemini returned invalid JSON: {exc}") from exc
