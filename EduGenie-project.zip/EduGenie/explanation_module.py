import os
from gemini_client import generate_text

SYSTEM = """
You explain difficult concepts to beginners.
Start with a one-sentence definition, then explain the idea step by step.
Use a simple analogy or example when it helps.
Avoid unnecessary jargon and keep the explanation readable.
"""

def explain_topic(topic: str) -> str:
    # The original project document proposes LaMini-Flan-T5 for local explanations.
    # This implementation defaults to Gemini so the project runs consistently with
    # one cloud dependency. A future local model adapter can be added behind this function.
    return generate_text(
        f"Explain this topic for a beginner:\n{topic}",
        system_instruction=SYSTEM,
        temperature=0.3,
        max_output_tokens=1000,
    )
