# EduGenie — Google Gemini Powered Learning Assistant

EduGenie is a FastAPI + HTML/CSS learning assistant based on the supplied project document.

## Features

- Q&A: `POST /qa`
- Concept explanation: `POST /explain`
- Quiz generation: `POST /quiz`
- Summarization: `POST /summarize`
- Learning recommendations: `POST /learn/recommendations`
- Browser UI at `/`
- Health check at `/health`
- Swagger API docs at `/docs`

## Project structure

```text
EduGenie/
├── main.py
├── gemini_client.py
├── explanation_module.py
├── qna.py
├── quiz_module.py
├── summary_module.py
├── learning_path.py
├── requirements.txt
├── .env.example
├── .gitignore
├── README.md
├── templates/
│   └── index.html
├── static/
│   └── style.css
└── tests/
    └── test_app.py
```

## VS Code setup

### 1. Open the project

Extract/open the `EduGenie` folder in VS Code.

### 2. Create a virtual environment

Windows PowerShell:

```powershell
py -3.10 -m venv .venv
.\.venv\Scripts\Activate.ps1
```

Windows Command Prompt:

```cmd
py -3.10 -m venv .venv
.venv\Scripts\activate
```

macOS/Linux:

```bash
python3 -m venv .venv
source .venv/bin/activate
```

### 3. Install dependencies

```bash
python -m pip install --upgrade pip
pip install -r requirements.txt
```

### 4. Configure Gemini

Copy `.env.example` to `.env` and put your Gemini API key in:

```env
GEMINI_API_KEY=your_real_key
GEMINI_MODEL=gemini-2.5-flash
```

Do not commit `.env` to Git.

### 5. Run

```bash
uvicorn main:app --reload
```

Open:

- http://127.0.0.1:8000
- API documentation: http://127.0.0.1:8000/docs

## Testing

Run the automated tests:

```bash
pytest
```

The health and homepage tests do not require a Gemini API call.

For manual testing, try:

- Q&A: `Which is the largest ocean?`
- Explain: `Explain the Pythagoras theorem for a beginner.`
- Quiz: paste a paragraph and generate 3 MCQs.
- Summary: paste a long educational paragraph.
- Learning path: `SQL`

## API examples

PowerShell:

```powershell
Invoke-RestMethod -Uri http://127.0.0.1:8000/qa `
  -Method Post `
  -ContentType "application/json" `
  -Body '{"text":"Which is the largest ocean?"}'
```

Quiz:

```powershell
Invoke-RestMethod -Uri http://127.0.0.1:8000/quiz `
  -Method Post `
  -ContentType "application/json" `
  -Body '{"text":"The water cycle describes evaporation, condensation and precipitation."}'
```

## Notes about the original specification

The supplied document specifies Gemini 1.5 Pro for Q&A, summaries, quizzes and learning paths, and LaMini-Flan-T5-783M for explanations. This implementation keeps the requested module structure and endpoints but uses the current Google GenAI Python SDK and Gemini model configuration so the application is easier to install and maintain today.

The explanation module is intentionally kept behind `explain_topic()` so a local LaMini-Flan-T5 adapter can be added later without changing the FastAPI API.

## Troubleshooting

### `GEMINI_API_KEY is not configured`
Make sure `.env` exists in the project root and contains a valid key.

### `ModuleNotFoundError`
Activate `.venv` and run:

```bash
pip install -r requirements.txt
```

### Port already in use

```bash
uvicorn main:app --reload --port 8001
```

Then open http://127.0.0.1:8001.

### Gemini model availability

If your API project does not expose the configured model, change `GEMINI_MODEL` in `.env` to a Gemini model available to your account.
