from gemini_client import generate_text

SYSTEM = """
You are an educational summarizer.
Summarize the supplied passage without losing its central facts.
Use a short heading followed by concise bullet points.
Do not introduce information that is absent from the source passage.
"""

def summarize_text(text: str) -> str:
    return generate_text(
        f"Passage to summarize:\n{text}",
        system_instruction=SYSTEM,
        temperature=0.2,
        max_output_tokens=900,
    )
